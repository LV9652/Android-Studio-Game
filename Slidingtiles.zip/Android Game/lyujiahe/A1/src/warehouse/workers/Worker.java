package warehouse.workers;

public class Worker {
}

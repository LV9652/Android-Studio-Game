# Markdown

Markdown is a plain-text file format. There are lots of programming tools that use Markdown, and it's useful and
easy to learn. Hash marks (the number sign) indicate headers. Asterisks indicate lists.

# Template

Use the following Code Smell template (copy and paste it at the end of this file and then edit it; don't include the "Begin template" or "End template" lines):

==== Begin template ====
## Code Smell: [Write the code smell name]

### Code Smell Category: [Write the code smell category name]

### List of classes and line numbers involved:

* [Write a class and list of line numbers, one class per asterisk, that describe the smell]

### Description:

[In your own words, explain how this particular code smells.]

### Solution:

[In your own words, explain how you might solve this code smell:
how would you refactor the code?]
==== End template ====

# List of code smells

## (1) Code Smell: Long Method

### Code Smell Category: Bloaters

### List of classes and line numbers involved:

* WarehouseSimulation   
lines 41~96

### Description:

The method "start" contains more than 15 lines.

### Solution:

Extract Method: <br>
To fix the Long Method, 
I'd extract lines 54~64 into a method called "addStartsWithOrder" 
and lines 66~77 into a method called "addStartsWithPicker" 
and lines 79~89 into a method called "addStartsWithSequencer", 
then extract the while loop (lines 50~92) into a method called "whileHasNext" 
where we call all the methods above. 
This brings the original method "start" down to 10 lines of code. 



## (2) Code Smell: Inappropriate Intimacy

### Code Smell Category: Couplers

### List of classes and line numbers involved:

* Order -- lines 28~31
* TranslationTable -- lines 52~55

### Description:

The constructor "Order" of class 'Order' takes TranslationTable 
as one of parameter types and also calls the method "getSKUs" of class 
'TraslationTable'.

### Solution:

Hide Delegate:<br>
I'd replace the parameter (TranslationTable translation) of method "Order" with (String[] skus) like: 

    public Order(int orderID, String colour, String model, String[] skus) {
        this.orderID = orderID;
        this.skus = skus;
    }
    
And I'd change line 55 of class 'WarehouseSimulation' like: 

    Order order = new Order(nextOrdersID++, orderParts[2], orderParts[1], 
                            translationTable.getSKUs(orderParts[2], orderParts[1]));

Then the client calls the method "getSKUs" directly and 
class 'Order' won't use methods of 'TranslationTable'.



## (3) Code Smell: Alternative Classes with Different Interfaces

### Code Smell Category: Object-Orientation Abusers

### List of classes and line numbers involved:

* PickerOrderList -- lines 9~105
* SequencerOrderList -- lines 9~105
* Picker -- lines 8~43
* Sequencer -- lines 8~45
* Worker -- lines 3~4

### Description:

The classes 'PickerOrderList' and 'SequencerOrderList' provide similar functionality but with different method and field names..

### Solution:

Extract Superclass: <br>
To fix Duplicate Code, 
I'd create an abstract superclass called 'OrderList' of 'PickerOrderList' and 'SequencerOrderList'.
Then move these fields (<strong>pickerSKUOrder, nextSKUToPick, orderID</strong>) 
of class 'PickerOrderList' and (<strong>sequencerSKUOrder, nextSKUToScan, orderID</strong>) 
of class 'SequencerOrderList' to the superclass 'OrderList' as protected fields 
(<strong>SKUOrder, nextSKUToPick, orderID</strong>). 

I'd create a constructor in the superclass: 

    public OrderList(int orderID) {
            this.orderID = orderID;
        }
              
The constructor in subclasses: 

    public PickerOrderList(int orderID) {
            super(orderID);

    public PickerOrderList(int orderID) {
            super(orderID);
        }

And I'd copy all methods in subclasses to the superclass except "toString". 
Remove them all in the subclasses except "toString". For example: 

from 

    public void addOrder(Order o) {
            pickerSKUOrder.add(o.getFrontSKU());
            pickerSKUOrder.add(o.getBackSKU());
        }
  
  to 
        
    public void addOrder(Order o) {
            SKUOrder.add(o.getFrontSKU());
            SKUOrder.add(o.getBackSKU());
        }
        
etc.

I'd also remould class 'Worker' as the superclass for 'Picker' and 'Sequencer'.



## (4) Code Smell: Dead Code

### Code Smell Category: Dispensables

### List of classes and line numbers involved:

* OrderException -- lines 1~7

### Description:

The classes 'OrderException' is never used (obsolete classes).

### Solution:

Delete unused code and unneeded fles: <br>
To fix Dead Code, I'd delete the whole class 'OrderException' 
(by deleting the file OrderException.java).



## (5) Code Smell: Temporary Field

### Code Smell Category: Object-Orientation Abusers

### List of classes and line numbers involved:

* WarehouseManager -- line 55

### Description:

The field <strong> sequenceOrderList </strong> is only needed by the method "sequencerSequenced" 
(lines 166~177 of class 'WarehouseManager'), and is otherwise never used.

### Solution:

To fix Temporary Field, I'd move line 55 to method "sequencerSequenced" as 
a local variable. The method is like below: 

        public void sequencerSequenced(String name) {
            String event;
            SequencerOrderList sequenceOrderList = null;
            if (pendingSequencingOrders.isEmpty()) {
                sequenceOrderList = null;
                nextSequencingIDIndex = -1;
                event = String.format("-> Sequencer ready; no pending sequencing lists.");
            } else {
                nextSequencingIDIndex++;
                sequenceOrderList = allSequencingOrderLists.get(nextSequencingIDIndex);
                event = String.format("-> Sequencer to sequence %s", sequenceOrderList);
            }
        }


